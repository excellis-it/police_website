<?php if(count($criminals) > 0): ?>
    <?php $__currentLoopData = $criminals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $criminal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>
                <?php echo e($criminals->firstItem() + $key); ?>

            </td>
            <td><?php echo e($criminal->name); ?></td>
            <td><?php echo e($criminal->policestation); ?></td>
            <td><?php echo e($criminal->case_no); ?></td>
            <td><?php echo e($criminal->under_section); ?></td>
            <td><?php echo e($criminal->address); ?></td>
            <td><?php echo e(date('d-m-Y', strtotime($criminal->created_at))); ?></td>
            <td>
                <?php echo e($criminal->arrest_date ? date('d-m-Y', strtotime($criminal->arrest_date)) : ''); ?>

            </td>
            <td>
                <div class="button-switch">
                    <input type="checkbox" id="switch-orange" class="switch toggle-class" data-id="<?php echo e($criminal['id']); ?>"
                        <?php echo e($criminal['status'] ? 'checked' : ''); ?> />
                    <label for="switch-orange" class="lbl-off"></label>
                    <label for="switch-orange" class="lbl-on"></label>
                </div>
            </td>
            <td>
                <div class="edit-1 d-flex align-items-center justify-content-center">
                    <a title="Edit Customer" href="<?php echo e(route('criminals.edit', $criminal->id) . (request()->page ? '?page=' . request()->page : '')); ?>">
                        <span class="edit-icon"><i class="ph ph-pencil-simple"></i></span>
                    </a>

                    <a title="Delete Customer" data-route="<?php echo e(route('criminals.delete', $criminal->id)); ?>"
                        href="javascipt:void(0);" id="delete"> <span class="trash-icon"><i
                                class="ph ph-trash"></i></span></a>
                </div>
            </td>

        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <tr>
        <td colspan="9">
            <div class="d-flex justify-content-center">
                <?php echo $criminals->links(); ?>

            </div>
        </td>
    </tr>
    <?php else: ?>
    <tr>
        <td colspan="9" class="text-center">No Data Found</td>
    </tr>
<?php endif; ?>
<?php /**PATH G:\new_xampp\htdocs\police_new\resources\views/admin/criminal/table.blade.php ENDPATH**/ ?>