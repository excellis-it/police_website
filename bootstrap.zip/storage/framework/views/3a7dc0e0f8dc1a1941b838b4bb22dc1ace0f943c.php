<div class="main-sidebar sidebar-style-2" tabindex="1">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="javascript:void(0);"><span class="logo-name"><img src="<?php echo e(asset('admin_assets/img/logo.png')); ?>" /></span> </a>
            <a href="javascript:void(0);"><span class="logo-fm"><img src="<?php echo e(asset('admin_assets/img/logo_fm.png')); ?>" /></span> </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header"></li>

            <li class="dropdown">
                <a href="javascript:void(0);" class="menu-toggle nav-link has-dropdown <?php echo e(Request::is('admin/profile*') || Request::is('admin/password*') || Request::is('admin/detail*') ? 'active' : ' '); ?>" >
                    <i class="ph-identification-card"></i>
                    <span>Manage Account</span>
                </a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Request::is('admin/profile*') ? 'active' : ' '); ?>"><a class="nav-link" href="<?php echo e(route('admin.profile')); ?>">My Profile</a></li>
                    <li class="<?php echo e(Request::is('admin/password*') ? 'active' : ' '); ?>"><a class="nav-link" href="<?php echo e(route('admin.password')); ?>">Change Password</a></li>
                </ul>
            </li>
            <li class="dropdown">
                <a href="javascript:void(0);" class="menu-toggle nav-link has-dropdown <?php echo e(Request::is('admin/criminals*') ? 'active' : ' '); ?>">
                    <i class="ph ph-user-list"></i>
                    <span> Suspects</span>
                </a>
                <ul class="dropdown-menu">
                    <li class="<?php echo e(Request::is('admin/criminals/create') ? 'active' : ' '); ?>"><a class="nav-link" href="<?php echo e(route('criminals.create')); ?>">Create  Suspect</a></li>
                    <li class="<?php echo e(Request::is('admin/criminals') ? 'active' : ' '); ?>"><a class="nav-link" href="<?php echo e(route('criminals.index')); ?>"> Suspect Entry List</a></li>
                </ul>
            </li>
            <li class="dropdown <?php echo e(Request::is('admin/slider-time-maintains*') ? 'active' : ' '); ?>">
                <a href="<?php echo e(route('slider-time-maintains.index')); ?>">
                    <i class="ph-gauge"></i>
                    <span>Slider Time Maintain</span>
                </a>
            </li>
            
        </ul>
    </aside>
</div>
<?php /**PATH G:\new_xampp\htdocs\police_new\resources\views/admin/includes/sidebar.blade.php ENDPATH**/ ?>