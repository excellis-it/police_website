<footer class="main-footer">
    <div class="footer-left">
        Developed by <a href="">Excellis IT.</a>
        <div class="bullet"></div>
        <a target="_blank" href=""></a>
    </div>
    <div class="footer-right"></div>
</footer>
<?php /**PATH G:\new_xampp\htdocs\police_new\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>