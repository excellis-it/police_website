
<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> | Edit Suspect Details
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('head'); ?>
    Edit Suspect Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="inner_page">
            <div class="card search_bar sales-report-card">
                <div class="sales-report-card-wrap">
                    <div class="form-head">
                        <div class="row">
                            <div class="col-md-6">
                                <h4>Main Information</h4>
                            </div>
                        </div>
                    </div>
                    <form action="<?php echo e(route('criminals.update', $criminal->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="page" value="<?php echo e(request()->page); ?>">
                        <div class="row">
                            <div class="col-md-10">
                                <div class="row justify-content-between">

                                    <div class="col-md-6">
                                        <div class="form-group-div">
                                            <div class="form-group">
                                                <label for="floatingInputValue">Name*</label>
                                                <input type="text" class="form-control" id="floatingInputValue"
                                                    name="name" value="<?php echo e($criminal->name); ?>" placeholder="Name*">
                                                <?php if($errors->has('name')): ?>
                                                    <div class="error" style="color:red;"><?php echo e($errors->first('name')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group-div">
                                            <div class="form-group">
                                                <label for="floatingInputValue">Profile Picture</label>
                                                <input type="file" class="form-control" id="floatingInputValue"
                                                    onchange="readURL(this);" name="profile_picture"
                                                    value="<?php echo e(old('profile_picture')); ?>" placeholder="Profile Picture*">
                                                <?php if($errors->has('profile_picture')): ?>
                                                    <div class="error" style="color:red;">
                                                        <?php echo e($errors->first('profile_picture')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group-div">
                                            <div class="form-group">
                                                <label for="floatingInputValue">Address*</label>
                                                <input type="text" class="form-control" id="floatingInputValue"
                                                    name="address" value="<?php echo e($criminal->address); ?>" placeholder="Address*">
                                                <?php if($errors->has('address')): ?>
                                                    <div class="error" style="color:red;"><?php echo e($errors->first('address')); ?>

                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="text-right">
                                    <?php if($criminal->profile_picture): ?>
                                        <img src="<?php echo e(Storage::url($criminal->profile_picture)); ?>" alt=""
                                            id="blah"
                                            style="width: 100%; height: 100%; border-radius: 10px; object-fit: cover; box-shadow: 5px 3px 10px rgb(0 0 0 / 25%);">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('assets/images/dummy.png')); ?>" alt="" id="blah"
                                            style="width: 100%; height: 100%; border-radius: 10px; object-fit: cover; box-shadow: 5px 3px 10px rgb(0 0 0 / 25%);">
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>


                </div>
                <div class="sales-report-card-wrap mt-5">
                    <div class="form-head">
                        <h4>Case Referance</h4>
                    </div>

                    <div class="row">
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group-div">
                                <div class="form-group">
                                    <label for="floatingInputValue">Police Station*</label>
                                    <input type="text" class="form-control" id="floatingInputValue" name="policestation"
                                        value="<?php echo e($criminal->policestation); ?>" placeholder="Police Station*">
                                    <?php if($errors->has('policestation')): ?>
                                        <div class="error" style="color:red;"><?php echo e($errors->first('policestation')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group-div">
                                <div class="form-group">
                                    <label for="floatingInputValue">Case No*</label>
                                    <input type="text" class="form-control" id="floatingInputValue" name="case_no"
                                        value="<?php echo e($criminal->case_no); ?>" placeholder="Case No*">
                                    <?php if($errors->has('case_no')): ?>
                                        <div class="error" style="color:red;"><?php echo e($errors->first('case_no')); ?></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group-div">
                                <div class="form-group">
                                    <label for="floatingInputValue">Under Section*</label>
                                    <input type="text" class="form-control" id="floatingInputValue" name="under_section"
                                        value="<?php echo e($criminal->under_section); ?>" placeholder="Under Section*">
                                    <?php if($errors->has('under_section')): ?>
                                        <div class="error" style="color:red;"><?php echo e($errors->first('under_section')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-6 col-md-6">
                            <div class="form-group-div">
                                <div class="form-group">
                                    <label for="floatingInputValue">Arrest Date*</label>
                                    <input type="date" class="form-control datepicker" id="floatingInputValue" max="<?php echo e(date('Y-m-d')); ?>" onfocus="'showPicker' in this && this.showPicker()"
                                        name="arrest_date" value="<?php echo e($criminal->arrest_date); ?>"
                                        placeholder="Arrest Date*">
                                    <?php if($errors->has('arrest_date')): ?>
                                        <div class="error" style="color:red;"><?php echo e($errors->first('arrest_date')); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-12">
                            <div class="btn-1">
                                <button type="submit">Update</button>
                            </div>
                        </div>
                    </div>
                </div>
                </form>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('#blah')
                        .attr('src', e.target.result);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\new_xampp\htdocs\police_new\resources\views/admin/criminal/edit.blade.php ENDPATH**/ ?>