<footer class="main-footer">
    <div class="footer-left">
        Developed by <a href="">Excellis IT.</a>
        <div class="bullet"></div>
        <a target="_blank" href=""></a>
    </div>
    <div class="footer-right"></div>
</footer>
